
#ifndef DECISION
#define DECISION

#include <iostream>

using namespace std;


char* GetPos(char pos[], char WorB);


#endif